package com.cognizant.assistant.service;

import java.util.List;

import com.cognizant.assistant.bean.MechRate;
import com.cognizant.assistant.bean.Mechanic;
import com.cognizant.assistant.bean.Rating;
import com.cognizant.assistant.dao.MechanicDAO;
import com.cognizant.assistant.dao.MechanicDAOImpl;

public class MechanicServiceImpl implements MechanicService {

	private static MechanicServiceImpl serviceImpl;
	private static MechanicDAO dao = MechanicDAOImpl.getInstance();

	public static MechanicServiceImpl getInstance() {
		if (serviceImpl == null) {
			serviceImpl = new MechanicServiceImpl();
			return serviceImpl;
		}
		return serviceImpl;
	}

	private MechanicServiceImpl() {

	}

	// Adding the mechanic details into the database
	@Override
	public int addMechanicDetails(Mechanic mechanic) {

		return dao.addMechanicDetails(mechanic);
	}

	// Fetching individual mechanic information by mechanicId from the database
	@Override
	public Mechanic getMechanic(int id) {

		return dao.getMechanic(id);
	}

	// Fetching all mechanic information
	@Override
	public List<Mechanic> getMechanicDetails() {

		return dao.getMechanicDetails();
	}

	// Fetching all data from rating table into sorted order
	@Override
	public List<Rating> getMechanicSorted() {

		return dao.getMechanicSorted();
	}

	// Adding rating of mechanic given by customer
	@Override
	public int addMechanicRating(Rating rat) {
		return dao.addMechanicRating(rat);
	}

	@Override
	public double getLatitude(int id) {
		return dao.getLatitude(id);
	}

	@Override
	public double getLongitude(int id) {
		return dao.getLongitude(id);
	}

	@Override
	public int addMechRate(MechRate mechRate) {
		
		return dao.addMechRate(mechRate);
	}

	@Override
	public List<MechRate> getMechRate() {
		return dao.getMechRate();
	}
	
	@Override
	public List<Integer> getMechanicId(int custId) {
		return dao.getMechanicId(custId);
	
	}

	@Override
	public int getMechanicId() {
		return dao.getMechanicId();
	}

	@Override
	public int updateMechRateStatus(int id,int status) {
		
		return dao.updateMechRateStatus(id,status);
	}

	@Override
	public int updateStatusCompleteService(int id, int status) {
		
		return dao.updateStatusCompleteService(id, status);
	}

	@Override
	public int updateMechRateRating(int id, double rate) {
		
		return dao.updateMechRateRating(id, rate);
	}

	@Override
	public int getNoOfCustomer(int id) {
		
		return dao.getNoOfCustomer(id);
	}

	@Override
	public int updateMechRateAvaibility(int id, int availibility) {
		
		return dao.updateMechRateAvaibility(id, availibility);
	}

	@Override
	public int updateStatusAvaibility(int id, int status, int avial) {
		
		return dao.updateStatusAvaibility(id, status, avial);
	}

}
