package com.cognizant.assistant.controller;

import java.io.IOException;

import javax.management.relation.RelationService;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.assistant.bean.Customer;
import com.cognizant.assistant.bean.RequestAccept;
import com.cognizant.assistant.service.RequestService;
import com.cognizant.assistant.service.RequestServiceImpl;


@WebServlet("/TrackServlet")
public class TrackServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TrackServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int mechId = Integer.parseInt(request.getParameter("mechid"));
		RequestService service = RequestServiceImpl.getInstance();
		RequestAccept accept = new RequestAccept();
		accept = service.getAllDetails(mechId);
		HttpSession session = request.getSession(false);
		session.setAttribute("accept", accept);
		RequestDispatcher dispatcher = request.getRequestDispatcher("track.jsp");
		dispatcher.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}
