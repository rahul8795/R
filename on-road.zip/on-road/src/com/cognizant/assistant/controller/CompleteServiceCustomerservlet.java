package com.cognizant.assistant.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.assistant.bean.MechRate;
import com.cognizant.assistant.service.MechanicService;
import com.cognizant.assistant.service.MechanicServiceImpl;

/**
 * Servlet implementation class CompleteServiceCustomerservlet
 */
@WebServlet("/CompleteServiceCustomerservlet")
public class CompleteServiceCustomerservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public CompleteServiceCustomerservlet() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		MechanicService mechanicService = MechanicServiceImpl.getInstance();
		HttpSession session = request.getSession(false);
		int mechId =Integer.parseInt(request.getParameter("mechId"));
		session.setAttribute("mechid", mechId);
		int r = mechanicService.updateMechRateStatus(mechId,0);
		List<MechRate> mechRate = mechanicService.getMechRate();
		session.setAttribute("mechRate",mechRate);
		
		RequestDispatcher dispatcher = null;
		dispatcher = request.getRequestDispatcher("feedback.jsp");
		dispatcher.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
