package com.cognizant.assistant.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.assistant.bean.Customer;
import com.cognizant.assistant.bean.MechRate;
import com.cognizant.assistant.bean.Rating;
import com.cognizant.assistant.service.MechanicService;
import com.cognizant.assistant.service.MechanicServiceImpl;


@WebServlet("/UpdateRating")
public class UpdateRating extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UpdateRating() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		double rate = Double.parseDouble(request.getParameter("rating"));
		MechanicService mechanicService = MechanicServiceImpl.getInstance();
		HttpSession session = request.getSession(false);
		int mechid = (int) session.getAttribute("mechid");
		Customer cust = (Customer) session.getAttribute("customer");
		int custid = cust.getCustomerId();
		
		Rating rating = new Rating();
		rating.setCustomerId(custid);
		rating.setMechanicId(mechid);
		rating.setRating(rate);
		int a = mechanicService.addMechanicRating(rating);
		
		int c = mechanicService.getNoOfCustomer(custid);
		rate = rate / c;
		int r = mechanicService.updateMechRateRating(mechid, rate);
		
		
		List<MechRate> mechRate = mechanicService.getMechRate();
		session.setAttribute("mechRate",mechRate);
		
		RequestDispatcher dispatcher = null;
		dispatcher = request.getRequestDispatcher("request.jsp");
		dispatcher.forward(request, response);
	}

}
