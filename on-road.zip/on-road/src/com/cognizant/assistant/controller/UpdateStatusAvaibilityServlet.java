package com.cognizant.assistant.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.assistant.bean.Request;
import com.cognizant.assistant.service.MechanicService;
import com.cognizant.assistant.service.MechanicServiceImpl;
import com.cognizant.assistant.service.RequestService;
import com.cognizant.assistant.service.RequestServiceImpl;

/**
 * Servlet implementation class UpdateStatusAvaibilityServlet
 */
@WebServlet("/UpdateStatusAvaibilityServlet")
public class UpdateStatusAvaibilityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateStatusAvaibilityServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int mechid = Integer.parseInt(request.getParameter("mechId"));
		MechanicService mechanicService = MechanicServiceImpl.getInstance();
		HttpSession session = request.getSession();
		RequestService service = RequestServiceImpl.getInstance();
		int r = mechanicService.updateStatusAvaibility(mechid,0,0);
		List<Request> customerRequest = service.getDetail(mechid);
		session.setAttribute("customerRequest",customerRequest);
		RequestDispatcher dispatcher = null;
		dispatcher = request.getRequestDispatcher("mechanic.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
