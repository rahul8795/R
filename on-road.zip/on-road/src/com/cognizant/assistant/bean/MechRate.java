package com.cognizant.assistant.bean;

public class MechRate {
	private int mechId;
	private double rate;
	private int status ;
	private int avaibility;
	
	public MechRate() {
		super();
	}
	public MechRate(int mechId, double rate, int status,int avaibility) {
		super();
		this.mechId = mechId;
		this.rate = rate;
		this.status = status;
		this.avaibility = avaibility;
	}
	public int getMechId() {
		return mechId;
	}
	public void setMechId(int mechId) {
		this.mechId = mechId;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getAvaibility() {
		return avaibility;
	}
	public void setAvaibility(int avaibility) {
		this.avaibility = avaibility;
	}
	
	
	

}
